﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PensionDisbursement
{
    public class ProcessPensionResponse
    {
        public int ProcessPensionStatusCode { get; set; }
    }
}
